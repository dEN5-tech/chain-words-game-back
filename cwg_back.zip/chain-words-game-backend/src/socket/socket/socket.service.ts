import { Injectable } from '@nestjs/common';
import { Server } from 'socket.io';
import { WebSocketGateway, WebSocketServer, OnGatewayInit } from '@nestjs/websockets';

@Injectable()
@WebSocketGateway({
  namespace: '/game', // Add your namespace if needed
  cors: {
    origin: '*', // Adjust the CORS settings as needed
  },
})
export class SocketService implements OnGatewayInit {
  @WebSocketServer()
  server: Server;

  afterInit(server: Server) {
    this.server = server;
    this.server.on('connect_error', (error) => {
      console.error('Connection error:', error);
    });
    this.server.on('disconnect', (reason) => {
      console.log('Disconnected:', reason);
    });
    this.server.on('connecting', () => {
      console.log('Connecting to server...');
    });
  }

  async publish(event: string, data: any): Promise<void> {
    this.server.emit(event, data);
  }

  asyncIterator<T>(eventName: string): AsyncIterator<T> {
    return {
      next: () => new Promise((resolve) => {
        this.server.on(eventName, (data) => resolve({ value: data, done: false }));
      }),
      return: () => Promise.resolve({ value: null, done: true }),
      throw: (error) => Promise.reject(error),
    };
  }
}