import { MiddlewareConsumer, Module, NestModule, RequestMethod } from '@nestjs/common';
import { GraphQLModule } from '@nestjs/graphql';
import { ApolloDriver, ApolloDriverConfig } from '@nestjs/apollo';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { LeaderboardModule } from './leaderboard/leaderboard.module';
import { ProxyMiddleware } from './middleware/proxy-middleware.middleware';
import { InMemoryStoreModule } from './in-memory-store/in-memory-store.module';
import { SocketModule } from './socket/socket.module';
import { WordsService } from './parser/words/words.service';
import loggerMiddleware from './middleware/logger.middleware';

@Module({
  imports: [
    GraphQLModule.forRoot<ApolloDriverConfig>({
      driver: ApolloDriver,
      playground: process.env.NODE_ENV !== 'production', // Only enable playground in non-production environments
      autoSchemaFile: true,
      context: ({ req }) => ({ req }),
      introspection: process.env.NODE_ENV !== 'production', // Only enable introspection in non-production environments
      path: '/graphql',
      installSubscriptionHandlers: true,
      subscriptions: {
        'graphql-ws': true,
      },
    }),
    LeaderboardModule,
    InMemoryStoreModule,
    SocketModule,
  ],
  controllers: [],
  providers: [AppService, WordsService],
})
export class AppModule implements NestModule {
  configure(consumer: MiddlewareConsumer) {
    consumer
      .apply(loggerMiddleware, ProxyMiddleware)
      .forRoutes({ path: '*', method: RequestMethod.ALL });
  }
}