import { Injectable } from '@nestjs/common';
import { parse } from 'node-html-parser';
import axios, { AxiosResponse } from 'axios';

@Injectable()
export class WordsService {
  constructor() {}

  async fetchWordsMaskPage(mask: string, page: number): Promise<string[]> {
    const url = `https://bezbukv.ru/mask/${encodeURIComponent(mask)}/noun?page=${page}&ajax=yw1`;
    const headers = {
      'Accept': '*/*',
      'Accept-Language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
      'Pragma': 'no-cache',
      'Referer': `https://bezbukv.ru/mask/${encodeURIComponent(mask)}/noun`,
      'Sec-Fetch-Dest': 'empty',
      'Sec-Fetch-Mode': 'cors',
      'Sec-Fetch-Site': 'same-origin',
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/112.0.0.0 Safari/537.36',
      'X-Requested-With': 'XMLHttpRequest',
      'sec-ch-ua': '" Not A;Brand";v="99", "Chromium";v="112"',
      'sec-ch-ch-ua-mobile': '?0',
      'sec-ch-ua-platform': '"Windows"'
    };

    try {
      const response: AxiosResponse = await axios.get(url, { headers });
      const root = parse(response.data);
      const elements = root.querySelectorAll('.view b');
      const words: string[] = [];
      elements.forEach(element => {
        const siblingTexts = element.nextSibling.textContent.trim().split('\n');
        siblingTexts.forEach(text => {
          const trimmedText = text.trim();
          if (trimmedText != '.') {
            words.push(trimmedText);
          }
        });
      });
      return words;
    } catch (error) {
      console.error('Failed to fetch words:', error);
      throw error;
    }
  }

  async fetchWordsMask(mask: string): Promise<string[]> {
    const words = [];
    const promises = [];
    for (let page = 1; page <= 1; page++) {
      promises.push(this.fetchWordsMaskPage(mask, page));
    }
    const results = await Promise.all(promises);
    results.forEach(wordsPage => words.push(...wordsPage));
    return words;
  }

  async isValidWord(word: string): Promise<boolean> {
    const words = await this.fetchWordsMask(word);
    return words.includes(word);
  }
}