import { Module } from '@nestjs/common';
import { InMemoryStoreService } from './in-memory-store.service';

@Module({
  providers: [InMemoryStoreService],
  exports: [InMemoryStoreService]
})
export class InMemoryStoreModule {}
