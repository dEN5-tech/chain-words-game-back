import { Injectable } from '@nestjs/common';

@Injectable()
export class InMemoryStoreService {
  private store: Map<string, any>;

  constructor() {
    this.store = new Map();
  }

  set(key: string, value: any): void {
    this.store.set(key, value);
  }

  get(key: string): any {
    return this.store.get(key);
  }

  del(key: string): void {
    this.store.delete(key);
  }

  keys(pattern: string): string[] {
    const regex = new RegExp(pattern.replace('*', '.*'));
    return Array.from(this.store.keys()).filter(key => regex.test(key));
  }
}