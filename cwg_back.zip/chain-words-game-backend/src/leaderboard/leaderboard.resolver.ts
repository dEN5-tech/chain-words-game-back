import { Resolver, Query, Mutation, Args, Subscription } from '@nestjs/graphql';
import { PubSub } from 'graphql-subscriptions';
import { ObjectType, Field, ID } from '@nestjs/graphql';
import { InMemoryStoreService } from '../in-memory-store/in-memory-store.service';
import { Inject } from '@nestjs/common';

const pubSub = new PubSub();

@ObjectType()
class WordSubmitted {
  @Field()
  word: string;

  @Field()
  userId: string;

  @Field()
  roomId: string;
}

@ObjectType()
class GameStarted {
  @Field()
  roomId: string;

  @Field()
  startTime: string;
}

@ObjectType()
class User {
  @Field(() => ID)
  id: string;

  @Field()
  username: string;

  @Field()
  score: number;
}

@ObjectType()
class Room {
  @Field(() => ID)
  id: string;

  @Field()
  name: string;

  @Field(() => [User])
  users: User[];
}

@ObjectType()
class UserAdded {
  @Field()
  userId: string;

  @Field()
  username: string;

  @Field()
  roomId: string;
}

@Resolver()
export class GameResolver {
  constructor(
    @Inject(InMemoryStoreService) private readonly inMemoryStore: InMemoryStoreService
  ) {
    console.log('GameResolver constructor');
  }

  @Query(() => String)
  async ping(): Promise<string> {
    console.log('ping query');
    return 'pong';
  }

  @Query(() => [User])
  async getUsers(@Args('roomId') roomId: string): Promise<User[]> {
    console.log('getUsers query', roomId);
    const users: User[] = this.inMemoryStore.get(`room:${roomId}:users`);
    console.log('users', users);
    return users || [];
  }

  @Query(() => Room)
  async getRoom(@Args('roomId') roomId: string): Promise<Room> {
    console.log('getRoom query', roomId);
    const room: Room = this.inMemoryStore.get(`room:${roomId}`);
    console.log('room', room);
    return room || { id: roomId, name: 'Unknown Room', users: [] };
  }

  @Mutation(() => Boolean)
  async submitWord(
    @Args('word') word: string,
    @Args('userId') userId: string,
    @Args('roomId') roomId: string
  ): Promise<boolean> {
    console.log('submitWord mutation', word, userId, roomId);
    // Logic to handle word submission
    await pubSub.publish('wordSubmitted', {
      wordSubmitted: { word, userId, roomId },
    });
    console.log('wordSubmitted event published');
    return true;
  }

  @Mutation(() => Boolean)
  async startGame(@Args('roomId') roomId: string): Promise<boolean> {
    console.log('startGame mutation', roomId);
    const startTime = new Date().toISOString();
    await pubSub.publish('gameStarted', {
      gameStarted: { roomId, startTime },
    });
    console.log('gameStarted event published');
    return true;
  }

  @Mutation(() => Boolean)
  async addUserToRoom(
    @Args('roomId') roomId: string,
    @Args('userId') userId: string,
    @Args('username') username: string
  ): Promise<boolean> {
    console.log('addUserToRoom mutation', roomId, userId, username);
    const user: User = { id: userId, username, score: 0 };
    let users: User[] = this.inMemoryStore.get(`room:${roomId}:users`) || [];
    users.push(user);
    this.inMemoryStore.set(`room:${roomId}:users`, users);
    console.log('user added to room', users);
    await pubSub.publish('userAdded', {
      userAdded: { userId, username, roomId },
    });
    console.log('userAdded event published');
    return true;
  }

  @Subscription(() => WordSubmitted, {
    name: 'wordSubmitted',
    filter: (payload, variables) => {
      console.log('wordSubmitted subscription filter', payload, variables);
      return payload.wordSubmitted.roomId === variables.roomId;
    },
    resolve: ({ wordSubmitted: { word, userId, roomId } }) => {
      console.log('wordSubmitted subscription resolve', word, userId, roomId);
      return {
        word,
        userId,
        roomId,
      };
    },
  })
  wordSubmitted(@Args('roomId') roomId: string) {
    console.log('wordSubmitted subscription', roomId);
    return pubSub.asyncIterator('wordSubmitted');
  }

  @Subscription(() => GameStarted, {
    name: 'gameStarted',
    filter: (payload, variables) => {
      console.log('gameStarted subscription filter', payload, variables);
      return payload.gameStarted.roomId === variables.roomId;
    },
    resolve: ({ gameStarted: { roomId, startTime } }) => {
      console.log('gameStarted subscription resolve', roomId, startTime);
      return {
        roomId,
        startTime,
      };
    },
  })
  gameStarted(@Args('roomId') roomId: string) {
    console.log('gameStarted subscription', roomId);
    return pubSub.asyncIterator('gameStarted');
  }

  @Subscription(() => UserAdded, {
    name: 'userAdded',
    filter: (payload, variables) => {
      console.log('userAdded subscription filter', payload, variables);
      return payload.userAdded.roomId === variables.roomId;
    },
    resolve: ({ userAdded: { userId, username, roomId } }) => {
      console.log('userAdded subscription resolve', userId, username, roomId);
      return {
        userId,
        username,
        roomId,
      };
    },
  })
  userAdded(@Args('roomId') roomId: string) {
    console.log('userAdded subscription', roomId);
    return pubSub.asyncIterator('userAdded');
  }
}