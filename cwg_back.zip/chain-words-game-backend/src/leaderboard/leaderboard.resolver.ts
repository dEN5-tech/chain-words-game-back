import { Resolver, Query, Mutation, Args, Subscription } from '@nestjs/graphql';
import { PubSub } from 'graphql-subscriptions';
import { ObjectType, Field, ID } from '@nestjs/graphql';
import { InMemoryStoreService } from '../in-memory-store/in-memory-store.service';
import { Inject } from '@nestjs/common';
import { WordsService } from '../parser/words/words.service';

const pubSub = new PubSub();

@ObjectType()
class WordSubmitted {
  @Field()
  word: string;

  @Field()
  userId: string;

  @Field()
  roomId: string;
}

@ObjectType()
class GameStarted {
  @Field()
  roomId: string;

  @Field()
  startTime: string;
}

@ObjectType()
class User {
  @Field(() => ID)
  id: string;

  @Field()
  username: string;

  @Field()
  score: number;

  @Field({ nullable: true })
  avatarUrl?: string;
}

@ObjectType()
class Room {
  @Field(() => ID)
  id: string;

  @Field()
  name: string;

  @Field(() => [User])
  users: User[];
}

@ObjectType()
class UserAdded {
  @Field()
  userId: string;

  @Field()
  username: string;

  @Field()
  roomId: string;

  @Field({ nullable: true })
  avatarUrl?: string;
}

@ObjectType()
class UserRemoved {
  @Field()
  userId: string;

  @Field()
  roomId: string;
}

@Resolver()
export class GameResolver {
  constructor(
    @Inject(InMemoryStoreService) private readonly inMemoryStore: InMemoryStoreService,
    @Inject(WordsService) private readonly wordsService: WordsService
  ) {
    console.log('GameResolver constructor');
  }

  @Query(() => String)
  async ping(): Promise<string> {
    console.log('ping query');
    return 'pong';
  }

  @Query(() => [User])
  async getUsers(@Args('roomId') roomId: string): Promise<User[]> {
    console.log('getUsers query', roomId);
    const users: User[] = this.inMemoryStore.get(`room:${roomId}:users`);
    console.log('users', users);
    return users || [];
  }

  @Query(() => Room)
  async getRoom(@Args('roomId') roomId: string): Promise<Room> {
    console.log('getRoom query', roomId);
    const room: Room = this.inMemoryStore.get(`room:${roomId}`);
    console.log('room', room);
    return room || { id: roomId, name: 'Unknown Room', users: [] };
  }

  @Query(() => [String])
  async fetchWordsByMask(@Args('mask') mask: string): Promise<string[]> {
    console.log('fetchWordsByMask query', mask);
    return this.wordsService.fetchWordsMask(mask);
  }

  @Query(() => Boolean)
  async isValidWord(@Args('word') word: string): Promise<boolean> {
    console.log('isValidWord query', word);
    return this.wordsService.isValidWord(word);
  }

  @Mutation(() => Boolean)
  async submitWord(
    @Args('word') word: string,
    @Args('userId') userId: string,
    @Args('roomId') roomId: string
  ): Promise<boolean> {
    console.log('submitWord mutation', word, userId, roomId);
    // Logic to handle word submission
    await pubSub.publish('wordSubmitted', {
      wordSubmitted: { word, userId, roomId },
    });
    console.log('wordSubmitted event published');
    return true;
  }

  @Mutation(() => Boolean)
  async startGame(@Args('roomId') roomId: string): Promise<boolean> {
    console.log('startGame mutation', roomId);
    const startTime = new Date().toISOString();
    await pubSub.publish('gameStarted', {
      gameStarted: { roomId, startTime },
    });
    console.log('gameStarted event published');
    return true;
  }

  @Mutation(() => Boolean)
  async addUserToRoom(
    @Args('roomId') roomId: string,
    @Args('userId') userId: string,
    @Args('username') username: string,
    @Args('avatarUrl', { nullable: true }) avatarUrl: string
  ): Promise<boolean> {
    console.log('addUserToRoom mutation', roomId, userId, username, avatarUrl);
    const user: User = { id: userId, username, score: 0, avatarUrl };
    let users: User[] = this.inMemoryStore.get(`room:${roomId}:users`) || [];
    users.push(user);
    this.inMemoryStore.set(`room:${roomId}:users`, users);
    console.log('user added to room', users);
    await pubSub.publish('userAdded', {
      userAdded: { userId, username, roomId, avatarUrl },
    });
    console.log('userAdded event published');
    return true;
  }

  @Mutation(() => Boolean)
  async removeUserFromRoom(
    @Args('roomId') roomId: string,
    @Args('userId') userId: string
  ): Promise<boolean> {
    console.log('removeUserFromRoom mutation', roomId, userId);
    let users: User[] = this.inMemoryStore.get(`room:${roomId}:users`) || [];
    users = users.filter(user => user.id !== userId);
    this.inMemoryStore.set(`room:${roomId}:users`, users);
    console.log('user removed from room', users);
    await pubSub.publish('userRemoved', {
      userRemoved: { userId, roomId },
    });
    console.log('userRemoved event published');
    return true;
  }

  @Subscription(() => WordSubmitted, {
    name: 'wordSubmitted',
    filter: (payload, variables) => {
      console.log('wordSubmitted subscription filter', payload, variables);
      return payload.wordSubmitted.roomId === variables.roomId;
    },
    resolve: ({ wordSubmitted: { word, userId, roomId } }) => {
      console.log('wordSubmitted subscription resolve', word, userId, roomId);
      return {
        word,
        userId,
        roomId,
      };
    },
  })
  wordSubmitted(@Args('roomId') roomId: string) {
    console.log('wordSubmitted subscription', roomId);
    return pubSub.asyncIterator('wordSubmitted');
  }

  @Subscription(() => GameStarted, {
    name: 'gameStarted',
    filter: (payload, variables) => {
      console.log('gameStarted subscription filter', payload, variables);
      return payload.gameStarted.roomId === variables.roomId;
    },
    resolve: ({ gameStarted: { roomId, startTime } }) => {
      console.log('gameStarted subscription resolve', roomId, startTime);
      return {
        roomId,
        startTime,
      };
    },
  })
  gameStarted(@Args('roomId') roomId: string) {
    console.log('gameStarted subscription', roomId);
    return pubSub.asyncIterator('gameStarted');
  }

  @Subscription(() => UserAdded, {
    name: 'userAdded',
    filter: (payload, variables) => {
      console.log('userAdded subscription filter', payload, variables);
      return payload.userAdded.roomId === variables.roomId;
    },
    resolve: ({ userAdded: { userId, username, roomId, avatarUrl } }) => {
      console.log('userAdded subscription resolve', userId, username, roomId, avatarUrl);
      return {
        userId,
        username,
        roomId,
        avatarUrl,
      };
    },
  })
  userAdded(@Args('roomId') roomId: string) {
    console.log('userAdded subscription', roomId);
    return pubSub.asyncIterator('userAdded');
  }

  @Subscription(() => UserRemoved, {
    name: 'userRemoved',
    filter: (payload, variables) => {
      console.log('userRemoved subscription filter', payload, variables);
      return payload.userRemoved.roomId === variables.roomId;
    },
    resolve: ({ userRemoved: { userId, roomId } }) => {
      console.log('userRemoved subscription resolve', userId, roomId);
      return {
        userId,
        roomId,
      };
    },
  })
  userRemoved(@Args('roomId') roomId: string) {
    console.log('userRemoved subscription', roomId);
    return pubSub.asyncIterator('userRemoved');
  }
}
