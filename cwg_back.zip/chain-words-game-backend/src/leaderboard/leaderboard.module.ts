import { Module } from '@nestjs/common';
import { GameResolver } from './leaderboard.resolver';
import { PubSubModule } from 'src/pubsub/pubsub.module';
import { InMemoryStoreModule } from '../in-memory-store/in-memory-store.module';

@Module({
  imports: [PubSubModule, InMemoryStoreModule],
  providers: [GameResolver],
})
export class LeaderboardModule {}
