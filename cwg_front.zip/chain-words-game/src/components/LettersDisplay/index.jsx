import { motion } from 'framer-motion';
import { Div } from '@vkontakte/vkui';

/**
 * LettersDisplay component displays the letters in a grid format.
 * Users can click on a letter to select it.
 * 
 * @param {Array} letters - 2D array of letters to display ({ "word": "СПГР", "userId": "6a49no" }).
 * @param {Function} handleLetterBoxClick - Function to handle click on a letter box.
 * @param {String} userId - The ID of the current user.
 */
const LettersDisplay = ({ letters, handleLetterBoxClick, userId }) => (
    <Div style={{ display: "flex", flexDirection: "column", alignItems: "center" }}>
      {letters.map((wordObj, wordIndex) => (
        <Div key={wordIndex} style={{ display: "flex", margin: "5px" }}>
          {wordObj.word.split('').map((letter, letterIndex) => (
            <motion.div
              key={`${wordIndex}-${letterIndex}`}
              onClick={() => handleLetterBoxClick(wordIndex, letterIndex)}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              style={{
                margin: "5px",
                width: "40px",
                height: "40px",
                backgroundColor: userId === wordObj.userId ? "#FFEB3B" : "#BDBDBD", // Bright Yellow if userId matches, else Grey
                color: "#000",
                fontSize: "18px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                borderRadius: "5px",
                cursor: "pointer",
              }}
            >
              {letter}
            </motion.div>
          ))}
        </Div>
      ))}
    </Div>
  );

export default LettersDisplay;