import { motion } from "framer-motion";
import { Button, Div } from "@vkontakte/vkui";

const keyboard = "ЙЦУКЕНГШЩЗХЪФЫВАПРОЛДЖЭЯЧСМИТЬБЮ".split("");

const MotionDiv = motion.div;

const Keyboard = ({ handleLetterClick }) => (
  <Div style={{ display: "flex", flexWrap: "wrap", justifyContent: "center" }}>
    {keyboard.map((letter, index) => (
      <MotionDiv
        key={index}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        <Button
          onClick={() => handleLetterClick(letter)}
          style={{
            margin: "5px",
            width: "40px",
            height: "40px",
            backgroundColor: "#D84315", // Orange
            color: "#FFF",
            fontSize: "18px",
          }}
        >
          {letter}
        </Button>
      </MotionDiv>
    ))}
  </Div>
);

export default Keyboard;
