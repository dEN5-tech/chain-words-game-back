import { motion } from "framer-motion";
import { Button, Div } from "@vkontakte/vkui";
import { memo } from "preact/compat";

const keyboard = "ЙЦУКЕНГШЩЗХЪФЫВАПРОЛДЖЭЯЧСМИТЬБЮ".split("");

const MotionDiv = motion.div;

const Keyboard = ({ mobile, handleLetterClick }) => {
  const buttonStyle = {
    margin: "5px",
    width: mobile ? "30px" : "40px",
    height: mobile ? "30px" : "40px",
    backgroundColor: "#D84315", // Orange
    color: "#FFF",
    fontSize: mobile ? "14px" : "18px",
  };

  return (
    <Div style={{ display: "flex", flexWrap: "wrap", justifyContent: "center" }}>
      {keyboard.map((letter, index) => (
        <MotionDiv
          key={index}
          whileHover={{ scale: 1.1 }}
          whileTap={{ scale: 0.9 }}
        >
          <Button
            onClick={() => handleLetterClick(letter)}
            style={buttonStyle}
          >
            {letter}
          </Button>
        </MotionDiv>
      ))}
    </Div>
  );
};

export default memo(Keyboard);

