import { motion } from "framer-motion";

const EmptyLetterBox = ({ letter, index, handleClick }) => (
  <motion.div
    initial={{ opacity: 0 }}
    animate={{ opacity: 1 }}
    exit={{ opacity: 0 }}
    whileHover={{ scale: 1.1 }}
    whileTap={{ scale: 0.9 }}
    onClick={() => handleClick(index)}
    style={{
      width: "40px",
      height: "40px",
      display: "inline-block",
      backgroundColor: "#FFF9C4", // Light Yellow
      color: "#000",
      lineHeight: "40px",
      textAlign: "center",
      margin: "5px",
      cursor: "pointer",
      border: "2px solid #000",
    }}
  >
    {letter}
  </motion.div>
);

export default EmptyLetterBox;