import { gql } from '@apollo/client';

export const START_GAME = gql`
mutation startGame($roomId: String!) {
  startGame(roomId: $roomId)
}
`;

export const SUBMIT_WORD = gql`
mutation submitWord($word: String!, $userId: String!, $roomId: String!) {
  submitWord(word: $word, userId: $userId, roomId: $roomId)
}
`;

export const ADD_USER_TO_ROOM = gql`
mutation addUserToRoom($roomId: String!, $userId: String!, $username: String!) {
  addUserToRoom(roomId: $roomId, userId: $userId, username: $username)
}
`;

export const GET_USERS = gql`
query getUsers($roomId: String!) {
  getUsers(roomId: $roomId) {
    id
    username
    score
  }
}
`;

export const GET_ROOM = gql`
query getRoom($roomId: String!) {
  getRoom(roomId: $roomId) {
    id
    name
    users {
      id
      username
      score
    }
  }
}
`;

export const GAME_STARTED = gql`
subscription gameStarted($roomId: String!) {
  gameStarted(roomId: $roomId) {
    roomId
    startTime
  }
}
`;

export const WORD_SUBMITTED = gql`
subscription wordSubmitted($roomId: String!) {
  wordSubmitted(roomId: $roomId) {
    word
    userId
    roomId
  }
}
`;
