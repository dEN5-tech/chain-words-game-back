import { render } from 'preact';
import App from './App';
import { ConfigProvider, AdaptivityProvider, AppRoot } from '@vkontakte/vkui';
import bridge from '@vkontakte/vk-bridge'; 
import { ApolloProvider } from '@apollo/client';
import { ApolloClient, InMemoryCache, HttpLink, split } from '@apollo/client';
import { getMainDefinition } from '@apollo/client/utilities';
import { GraphQLWsLink } from '@apollo/client/link/subscriptions';
import { createClient } from 'graphql-ws';
import { RouterProvider, createHashRouter } from '@vkontakte/vk-mini-apps-router';
// Initialize VK Bridge
bridge.send("VKWebAppInit");

// Subscribe to VK Bridge events
bridge.subscribe((e) => {
  if (e.detail.type === 'VKWebAppUpdateConfig') {
    console.log('Config updated:', e.detail.data);
  }
});

// Resize window if supported
if (bridge.supports("VKWebAppResizeWindow")) {
    bridge.send("VKWebAppResizeWindow", {"width": 800, "height": 1000});
}

const router = createHashRouter([
  {
    path: '/',
    panel: 'home_panel',
    view: 'default_view',
  },
  {
    path: '/room/:roomId',
    panel: 'room_panel',
    view: 'default_view',
  }
]);



// Apollo GraphQL setup
const httpLink = new HttpLink({
  uri: 'http://localhost:3001/graphql',
});

const wsLink = new GraphQLWsLink(createClient({
  url: 'ws://localhost:3001/graphql',
}));

const splitLink = split(
  ({ query }) => {
    const definition = getMainDefinition(query);
    return (
      definition.kind === 'OperationDefinition' &&
      definition.operation === 'subscription'
    );
  },
  wsLink,
  httpLink,
);

const client = new ApolloClient({
  link: splitLink,
  cache: new InMemoryCache(),
});

// Render the application
render(
  <ConfigProvider>
    <AdaptivityProvider>
      <AppRoot>
        <ApolloProvider client={client}>
          <RouterProvider router={router}>
            <App />
          </RouterProvider>
        </ApolloProvider>
      </AppRoot>
    </AdaptivityProvider>
  </ConfigProvider>,
    document.getElementById('root')
);

