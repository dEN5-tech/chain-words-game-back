import { render } from 'preact';
import App from './App';
import { ConfigProvider, AdaptivityProvider } from '@vkontakte/vkui';
import bridge from '@vkontakte/vk-bridge'; 
import { ApolloProvider } from '@apollo/client';
import { ApolloClient, InMemoryCache, HttpLink, split } from '@apollo/client';
import { getMainDefinition } from '@apollo/client/utilities';
import { GraphQLWsLink } from '@apollo/client/link/subscriptions';
import { createClient } from 'graphql-ws';

bridge.send("VKWebAppInit");

bridge.subscribe((e) => console.log(e)); 

if (bridge.supports("VKWebAppResizeWindow")) {
    bridge.send("VKWebAppResizeWindow", {"width": 800, "height": 1000});
}

const httpLink = new HttpLink({
  uri: 'http://localhost:3001/graphql',
});

const wsLink = new GraphQLWsLink(createClient({
  url: 'ws://localhost:3001/graphql',
}));

const splitLink = split(
  ({ query }) => {
    const definition = getMainDefinition(query);
    return (
      definition.kind === 'OperationDefinition' &&
      definition.operation === 'subscription'
    );
  },
  wsLink,
  httpLink,
);

const client = new ApolloClient({
  link: splitLink,
  cache: new InMemoryCache(),
});

render(
    <ApolloProvider client={client}>
        <ConfigProvider>
            <AdaptivityProvider>
                <App />
            </AdaptivityProvider>
        </ConfigProvider>
    </ApolloProvider>,
    document.getElementById('root')
);
