import {
  ConfigProvider,
  ViewWidth,
  useAdaptivity,
  AdaptivityProvider,
  AppRoot,
  Panel,
  PanelHeader,
  SplitLayout,
  SplitCol,
  Group,
  Button,
  Div,
  Avatar,
  Root,
  View,
  PanelHeaderContent,
  Card,
} from "@vkontakte/vkui";
import { motion } from "framer-motion";
import "@vkontakte/vkui/dist/vkui.css";
import { useState, useEffect } from "preact/hooks";
import { gql, useLazyQuery, useMutation, useSubscription } from "@apollo/client";
import {
  SUBMIT_WORD,
  WORD_SUBMITTED,
  GAME_STARTED,
  ADD_USER_TO_ROOM,
  USER_ADDED,
  REMOVE_USER_FROM_ROOM,
  USER_REMOVED,
  FETCH_WORDS_BY_MASK,
} from "./graphql/queries";
import LettersDisplay from "./components/LettersDisplay";
import EmptyLetterBox from "./components/EmptyLetterBox";
import Keyboard from "./components/Keyboard";
import bridge from "@vkontakte/vk-bridge";
import {
  createHashRouter,
  RouteWithRoot,
  useActiveVkuiLocation,
  useGetPanelForView,
  useParams,
  useRouteNavigator,
} from "@vkontakte/vk-mini-apps-router";
import { Icon24LightbulbOutline } from "@vkontakte/icons";

const MotionDiv = motion.div;

const container = {
  hidden: { opacity: 1, scale: 0 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: {
      delayChildren: 0.3,
      staggerChildren: 0.2,
    },
  },
};

const item = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1,
  },
};

const ScoreDisplay = ({ score }) => (
  <Div style={{ textAlign: "center", color: "#FFC107", fontSize: "24px" }}>
    {" "}
    {/* Yellow */}
    <h2>Score: {score}</h2>
  </Div>
);

const ConnectedUsers = ({ users, activeUserId }) => (
  <motion.div
    variants={container}
    initial="hidden"
    animate="visible"
    style={{
      display: "flex",
      padding: 16,
      gap: 12,
      flexFlow: "row wrap",
    }}
  >
    {users.map((user) => (
      <motion.div
        key={user.id}
        variants={item}
        whileHover={{ scale: 1.2, borderColor: "#FF5733" }} // Red color for hover effect
      >
        <Avatar
          size={56}
          src={user.avatarUrl}
          alt={user.name}
          style={{
            border: `2px solid ${
              user.id === activeUserId ? user.color : "#040406"
            }`,
          }} // Red border for avatars
        />
      </motion.div>
    ))}
  </motion.div>
);

const App = () => {
  const { view: activeView } = useActiveVkuiLocation();
  const activePanel = useGetPanelForView("default_view");
  const { roomId } = useParams();

  const { viewWidth } = useAdaptivity();
  const isMobile = viewWidth <= ViewWidth.MOBILE;
  const [wordSubmitted, setWordSubmitted] = useState([]);
  const { data: subscriptionData } = useSubscription(WORD_SUBMITTED, {
    variables: { roomId },
  });
  const { data: gameStartedData } = useSubscription(GAME_STARTED, {
    variables: { roomId },
  });

  const { data: userAddedData } = useSubscription(USER_ADDED, {
    variables: { roomId },
  });

  const { data: userRemovedData } = useSubscription(USER_REMOVED, {
    variables: { roomId },
  });

  const [submitWord] = useMutation(SUBMIT_WORD);

  const [addUserToRoom] = useMutation(ADD_USER_TO_ROOM);

  const [removeUserFromRoom] = useMutation(REMOVE_USER_FROM_ROOM);

  const [fetchWordsByMask, { data: fetchWordsByMaskData }] = useLazyQuery(FETCH_WORDS_BY_MASK);

  const [score, setScore] = useState(20);
  const [selectedLetters, setSelectedLetters] = useState([]);
  const [letters, setLetters] = useState([]);
  const [newWord, setNewWord] = useState(null);
  const [emptyBoxes, setEmptyBoxes] = useState([]);
  const [userId, setUserId] = useState(null);
  const [tintsCount, setTintsCount] = useState(5);
  const randomColors = [
    "#FF5733",
    "#33FF57",
    "#3357FF",
    "#FF33A1",
    "#A133FF",
    "#33FFF5",
  ];
  const getRandomColor = () =>
    randomColors[Math.floor(Math.random() * randomColors.length)];

  const [connectedUsers, setConnectedUsers] = useState([]);

  const routeNavigator = useRouteNavigator();

  useEffect(() => {
    bridge
      .send("VKWebAppGetUserInfo")
      .then((data) => {
        if (data.id) {
          setUserId(data.id.toString());
          addUserToRoom({
            variables: {
              roomId: roomId,
              userId: data.id.toString(),
              username: data.first_name,
              avatarUrl: data.photo_200,
            },
          });
        }
      })
      .catch((error) => {
        console.log("Error fetching user info:", error);
      });

    return () => {
      removeUserFromRoom({
        variables: {
          roomId: roomId,
          userId: userId,
        },
      });
    };
  }, []);

  useEffect(() => {
    const handleBeforeUnload = (event) => {
      event.preventDefault();
      removeUserFromRoom({
        variables: {
          roomId: roomId,
          userId: userId,
        },
      });
      event.returnValue = "";
    };

    window.addEventListener("beforeunload", handleBeforeUnload);

    return () => {
      window.removeEventListener("beforeunload", handleBeforeUnload);
    };
  }, [roomId, userId]);

  useEffect(() => {
    if (subscriptionData) {
      const wordSubmitted_ = subscriptionData.wordSubmitted;
      const newWord = wordSubmitted_.word;
      const newWordUserId = wordSubmitted_.userId;
      setLetters((prevLetters) => [
        ...prevLetters,
        { word: newWord, userId: newWordUserId },
      ]);
      setScore((prevScore) => prevScore + newWord.length);
      setWordSubmitted((prevWordSubmitted) => [
        ...prevWordSubmitted,
        wordSubmitted_,
      ]);
      console.log(wordSubmitted_);
    }
  }, [subscriptionData]);

  useEffect(() => {
    if (gameStartedData) {
      const gameStarted_ = gameStartedData.gameStarted;
      const startTime = gameStarted_.startTime;
      console.log(`Game started at ${startTime}`);
    }
  }, [gameStartedData]);

  useEffect(() => {
    if (userAddedData) {
      const newUser = userAddedData.userAdded;
      setConnectedUsers((prevUsers) => [
        ...prevUsers,
        {
          id: newUser.userId,
          name: newUser.username,
          avatarUrl: newUser.avatarUrl,
          color: getRandomColor(),
        },
      ]);
    }
  }, [userAddedData]);

  useEffect(() => {
    if (userRemovedData) {
      const removedUserId = userRemovedData.userRemoved.userId;
      setConnectedUsers((prevUsers) =>
        prevUsers.filter((user) => user.id !== removedUserId)
      );
    }
  }, [userRemovedData]);


  useEffect(() => {
    if (Array.isArray(emptyBoxes)) {
      const writedWord = emptyBoxes.map((letter) => letter).join("").toLowerCase();
      if (writedWord.length === 2) {
        fetchWordsByMask({ variables: { mask: writedWord + "$" } });
      }
    }
  }, [emptyBoxes]);


  useEffect(() => {
    if (fetchWordsByMaskData) {
      const words = fetchWordsByMaskData.fetchWordsByMask;
      console.log(words);
    }
  }, [fetchWordsByMaskData]);

  const handleLetterBoxClick = (wordIndex, letterIndex) => {
    const letter = letters[wordIndex].word[letterIndex];
    setSelectedLetters((prevSelectedLetters) => [
      ...prevSelectedLetters,
      letter,
    ]);
  };

  const handleEmptyBoxClick = (index) => {
    setEmptyBoxes((prevEmptyBoxes) => {
      const newEmptyBoxes = [...prevEmptyBoxes];
      newEmptyBoxes.splice(index, 1);
      return newEmptyBoxes;
    });
  };

  const handleLetterClick = (letter) => {
    setEmptyBoxes((prevEmptyBoxes) => [...prevEmptyBoxes, letter]);
  };

  const handleSubmit = async () => {
    if (emptyBoxes.length > 0) {
      const newWord = emptyBoxes.join("");
      setEmptyBoxes([]);
      setScore((prevScore) => prevScore + emptyBoxes.length);
      setNewWord(newWord);
      try {
        await submitWord({
          variables: { word: newWord, userId: userId, roomId: roomId },
        });
        setEmptyBoxes(newWord.toLowerCase().slice(-2).split(''));
      } catch (error) {
        console.error("Error submitting word:", error);
      }
    }
  };

  useEffect(() => {
    if (newWord) {
      const timer = setTimeout(() => {
        setNewWord(null);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [newWord]);

  const randomHash = () => {
    return (
      Math.random().toString(36).substring(2, 15) +
      Math.random().toString(36).substring(2, 15)
    );
  };

  const handleHelperWord = async () => {
    const data = fetchWordsByMaskData?.fetchWordsByMask;
    if (data) {
      setTintsCount(tintsCount - 1);
      setEmptyBoxes(data[Math.floor(Math.random() * data.length)].split(''));
    }
  };

  return (
    <Root activeView={activeView}>
      <View nav="default_view" activePanel={activePanel}>
        <Panel
          nav="room_panel"
          before="Word Game Mode"
          separator={false}
          after={
            <ConnectedUsers users={connectedUsers} activeUserId={userId} />
          }
        >
          <PanelHeader
            separator={false}
            after={
              <ConnectedUsers users={connectedUsers} activeUserId={userId} />
            }
          />
          <Group>
            <ScoreDisplay score={score} />
            {letters.length > 0 ? (
              <LettersDisplay
                letters={letters}
                handleLetterBoxClick={handleLetterBoxClick}
                userId={userId}
              />
            ) : (
              <MotionDiv
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                transition={{ duration: 1 }}
                style={{
                  display: "flex",
                  marginTop: 10,
                  justifyContent: "center",
                }}
              >
                <Div>Напишите слово</Div>
              </MotionDiv>
            )}
            <Div
              style={{
                display: "flex",
                marginTop: 10,
                justifyContent: "center",
              }}
            >
              {Array.isArray(emptyBoxes) && emptyBoxes.map((letter, index) => (
                <EmptyLetterBox
                  key={index}
                  letter={letter}
                  index={index}
                  handleClick={handleEmptyBoxClick}
                />
              ))}
            </Div>
            <Keyboard mobile={isMobile} handleLetterClick={handleLetterClick} />
            <MotionDiv
              style={{ marginTop: 20, textAlign: "center" }}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
            >
              <Button
                size="l"
                stretched
                style={{ backgroundColor: "#f81401", color: "#FFF" }} // Red from swatch
                onClick={handleSubmit}
                disabled={emptyBoxes.length === 0}
              >
                {emptyBoxes.length > 0 ? "Отправить" : "Закончить"}
              </Button>{" "}
            </MotionDiv>
            <MotionDiv>
              <Button
                size="l"
                stretched
                before={<Icon24LightbulbOutline />}
                after={<Div>{tintsCount}</Div>}
                disabled={tintsCount === 0}
                style={{
                  backgroundColor: "#FFC107",
                  color: "#FFF",
                  marginTop: 10,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }} // Yellow from swatch
                onClick={handleHelperWord}
              >
                Помощь
              </Button>
            </MotionDiv>
          </Group>
        </Panel>

        <Panel
          nav="home_panel"
          style={{
            display: "flex",
            justifyContent: "center",
            alignItems: "center",
            height: "100vh",
          }}
        >
          <Card
            style={{
              padding: 20,
              boxShadow: "0 2px 10px rgba(0,0,0,0.1)",
              borderRadius: 10,
            }}
          >
            <Group>
              <Div style={{ textAlign: "center", marginBottom: 20 }}>
                <h2>Select Genre of Game</h2>
              </Div>
              <Div style={{ display: "flex", justifyContent: "space-around" }}>
                <Button
                  onClick={() => routeNavigator.push(`/room/${randomHash()}`)}
                >
                  Start Game
                </Button>
                <Button onClick={() => routeNavigator.push("/")}>тест</Button>
              </Div>
            </Group>
          </Card>
        </Panel>
      </View>
    </Root>
  );
};

export default App;
