import {
  ConfigProvider,
  ViewWidth,
  useAdaptivity,
  AdaptivityProvider,
  AppRoot,
  Panel,
  PanelHeader,
  SplitLayout,
  SplitCol,
  Group,
  Button,
  Div,
  Avatar,
} from "@vkontakte/vkui";
import { motion } from "framer-motion";
import "@vkontakte/vkui/dist/vkui.css";
import { useState, useEffect } from "preact/hooks";
import { gql, useMutation, useSubscription } from "@apollo/client";
import { SUBMIT_WORD, WORD_SUBMITTED, GAME_STARTED } from "./graphql/queries";
import LettersDisplay from "./components/LettersDisplay";
import EmptyLetterBox from "./components/EmptyLetterBox";
import Keyboard from "./components/Keyboard";


const MotionDiv = motion.div;

const container = {
  hidden: { opacity: 1, scale: 0 },
  visible: {
    opacity: 1,
    scale: 1,
    transition: {
      delayChildren: 0.3,
      staggerChildren: 0.2
    }
  }
}
  
const item = {
  hidden: { y: 20, opacity: 0 },
  visible: {
    y: 0,
    opacity: 1
  }
}

const ScoreDisplay = ({ score }) => (
  <Div style={{ textAlign: "center", color: "#FFC107", fontSize: "24px" }}> {/* Yellow */}
    <h2>Score: {score}</h2>
  </Div>
);

const ConnectedUsers = ({ users, activeUserId }) => (
  <motion.div
    variants={container}
    initial="hidden"
    animate="visible"
    style={{
      display: 'flex',
      padding: 16,
      gap: 12,
      flexFlow: 'row wrap'
    }}
  >
    {users.map((user) => (
      <motion.div
        key={user.id}
        variants={item}
        whileHover={{ scale: 1.2, borderColor: "#FF5733" }} // Red color for hover effect
      >
        <Avatar
          size={56}
          src={user.avatarUrl}
          alt={user.name}
          style={{ border: `2px solid ${user.id === activeUserId ? user.color : '#040406'}` }} // Red border for avatars
        />
      </motion.div>
    ))}
  </motion.div>
);

const App = () => {
  const { viewWidth } = useAdaptivity();
  const isMobile = viewWidth <= ViewWidth.MOBILE;
  const [wordSubmitted, setWordSubmitted] = useState([]);
  const { data: subscriptionData } = useSubscription(WORD_SUBMITTED, {
    variables: { roomId: "defaultRoomId" }
  });
  const { data: gameStartedData } = useSubscription(GAME_STARTED, {
    variables: { roomId: "defaultRoomId" }
  });
  const [submitWord] = useMutation(SUBMIT_WORD);

  const [score, setScore] = useState(20);
  const [selectedLetters, setSelectedLetters] = useState([]);
  const [letters, setLetters] = useState([]);
  const [newWord, setNewWord] = useState(null);
  const [emptyBoxes, setEmptyBoxes] = useState([]);
  const [userId, setUserId] = useState(null);
  const [roomId, setRoomId] = useState("defaultRoomId"); // Set a default roomId or fetch it from somewhere
  const randomColors = ["#FF5733", "#33FF57", "#3357FF", "#FF33A1", "#A133FF", "#33FFF5"];
  const getRandomColor = () => randomColors[Math.floor(Math.random() * randomColors.length)];

  const [connectedUsers, setConnectedUsers] = useState([
    { id: "user1", name: "Alice", avatarUrl: "https://randomuser.me/api/portraits/women/1.jpg", color: getRandomColor() },
    { id: "user2", name: "Bob", avatarUrl: "https://randomuser.me/api/portraits/men/2.jpg", color: getRandomColor() },
    { id: "user3", name: "Charlie", avatarUrl: "https://randomuser.me/api/portraits/men/3.jpg", color: getRandomColor() },
    { id: "user4", name: "Diana", avatarUrl: "https://randomuser.me/api/portraits/women/4.jpg", color: getRandomColor() }
  ]);

  useEffect(() => {
    if (subscriptionData) {
      const wordSubmitted_ = subscriptionData.wordSubmitted;
      const newWord = wordSubmitted_.word;
      const newWordUserId = wordSubmitted_.userId;
      setLetters((prevLetters) => [...prevLetters, { word: newWord, userId: newWordUserId }]);
      setScore((prevScore) => prevScore + newWord.length);
      setWordSubmitted((prevWordSubmitted) => [...prevWordSubmitted, wordSubmitted_]);
      console.log(wordSubmitted);
    }
  }, [subscriptionData]);

  useEffect(() => {
    if (gameStartedData) {
      const gameStarted_ = gameStartedData.gameStarted;
      const startTime = gameStarted_.startTime;
      console.log(`Game started at ${startTime}`);
    }
  }, [gameStartedData]);

  useEffect(() => {
    const newUserId = Math.random().toString(36).substring(7);
    setUserId(newUserId);
    setConnectedUsers((prevUsers) => 
      prevUsers.map((user) => 
        user.id === "user1" ? { ...user, id: newUserId } : user
      )
    );
  }, []);

  const handleLetterBoxClick = (wordIndex, letterIndex) => {
    const letter = letters[wordIndex].word[letterIndex];
    setSelectedLetters((prevSelectedLetters) => [...prevSelectedLetters, letter]);
  };

  const handleEmptyBoxClick = (index) => {
    setEmptyBoxes((prevEmptyBoxes) => {
      const newEmptyBoxes = [...prevEmptyBoxes];
      newEmptyBoxes.splice(index, 1);
      return newEmptyBoxes;
    });
  };

  const handleLetterClick = (letter) => {
    setEmptyBoxes((prevEmptyBoxes) => [...prevEmptyBoxes, letter]);
  };

  const handleSubmit = async () => {
    if (emptyBoxes.length > 0) {
      const newWord = emptyBoxes.join("");
      setEmptyBoxes([]);
      setScore((prevScore) => prevScore + emptyBoxes.length);
      setNewWord(newWord);
      try {
        await submitWord({ variables: { word: newWord, userId: userId, roomId: roomId } });
      } catch (error) {
        console.error("Error submitting word:", error);
      }
    }
  };
  

  useEffect(() => {
    if (newWord) {
      const timer = setTimeout(() => {
        setNewWord(null);
      }, 1000);
      return () => clearTimeout(timer);
    }
  }, [newWord]);

  return (
    <ConfigProvider platform="android">
      <AdaptivityProvider>
        <AppRoot>
          <SplitLayout
            style={{ justifyContent: "center", backgroundColor: "#040406", maxHeight: '280px' }} // Black from swatch
          >
            <SplitCol spaced={viewWidth > ViewWidth.MOBILE}>
              <Panel>
              <PanelHeader before={`Word Game Mode`} separator={false} after={<ConnectedUsers
               users={connectedUsers}
               activeUserId={userId}
                />}>
              </PanelHeader>
                <Group>
                  <ScoreDisplay score={score} />
                  {letters.length > 0 ? (
                    <LettersDisplay
                      letters={letters}
                      handleLetterBoxClick={handleLetterBoxClick}
                      userId={userId}
                    />
                  ) : (
                    <MotionDiv
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ duration: 1 }}
                      style={{ display: "flex", marginTop: "10px", justifyContent: "center" }}
                    >
                      <Div>Напишите слово</Div>
                    </MotionDiv>
                  )}
                  <Div style={{ display: "flex", marginTop: "10px", justifyContent: "center" }}>
                    {emptyBoxes.map((letter, index) => (
                      <EmptyLetterBox
                        key={index}
                        letter={letter}
                        index={index}
                        handleClick={handleEmptyBoxClick}
                      />
                    ))}
                  </Div>
                  <Keyboard handleLetterClick={handleLetterClick} />
                  <MotionDiv
                    style={{ marginTop: "20px", textAlign: "center" }}
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    whileHover={{ scale: 1.1 }}
                    whileTap={{ scale: 0.9 }}
                  >
                    <Button
                      size="l"
                      stretched
                      style={{ backgroundColor: "#f81401", color: "#FFF" }} // Red from swatch
                      onClick={handleSubmit}
                    >
                      Отправить
                    </Button>
                  </MotionDiv>
                </Group>
              </Panel>
            </SplitCol>
          </SplitLayout>
        </AppRoot>
      </AdaptivityProvider>
    </ConfigProvider>
  );
};


export default App;
